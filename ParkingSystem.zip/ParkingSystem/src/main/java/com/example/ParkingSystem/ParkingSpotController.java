package com.example.ParkingSystem;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ParkingSpotController {

	@Autowired
	private ParkingSpot_Service service;
	// private ParkingSpot_Repository repositry;;
	// List all users

	/*
	 * @GetMapping("/users") public String listAllUsers(Model model) {
	 * List<UserEntity> users = service.findAll(); model.addAttribute("userEntity",
	 * users); return "list-spots";}
	 */

	@GetMapping("/users")
	public String listAllUsers(Model model) {
		// model.addAttribute("userEntity", service.findAll());
		List<UserEntity> users = service.findAll();
		model.addAttribute("userEntity", users);
		return "list-spots";
	}

	// Show the form to create a new user
	@GetMapping("/users/new")
	public String createUserForm(Model model) {
		model.addAttribute("userEntity", new UserEntity());
		return "create-spot";
	}

	// Save a new user
	@PostMapping("/users")
	public String saveUser(@ModelAttribute UserEntity user) {
		service.save(user);
		return "redirect:/users";
	}

	// Show the form to update an existing user
	@GetMapping("/users/edit/{id}")
	public String updateUserForm(@PathVariable Long id, Model model) {
		//model.addAttribute("user", service.findById(id));
		UserEntity user = service.findById(id);
	    model.addAttribute("userEntity", user);
		return "edit-spot";
	}

	// Update a user
	@PostMapping("/users/{id}")
	public String updateUser(@PathVariable Long id, @ModelAttribute UserEntity user) {
		user.setId(id); // Assuming UserEntity has a setId method
		service.save(user);
		return "redirect:/users";
	}

	// Delete a user
	@GetMapping("/users/delete/{id}")
	public String deleteUser(@PathVariable Long id) {
		service.delete(id);
		return "redirect:/users";
	}
	// List all parking spots

}
