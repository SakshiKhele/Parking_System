package com.example.ParkingSystem;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ParkingSpot_Repository extends JpaRepository<UserEntity, Long>  {

}
