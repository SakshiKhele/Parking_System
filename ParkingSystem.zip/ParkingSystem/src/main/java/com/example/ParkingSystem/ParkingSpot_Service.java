package com.example.ParkingSystem;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ParkingSpot_Service {


	    @Autowired
	    private ParkingSpot_Repository repository;

		
		  public List<UserEntity> findAll() { 
			  return repository.findAll(); 
			  }
		 

	    public UserEntity save(UserEntity userentity) {
	        return repository.save(userentity);
	    }

	    public UserEntity findById(Long id) {
	        return repository.findById(id).orElse(null);
	    }

	    public void delete(Long id) {
	        repository.deleteById(id);
	    }
	}
